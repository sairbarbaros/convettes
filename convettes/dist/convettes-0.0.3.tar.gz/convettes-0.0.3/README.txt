This is a convolutional neural network library for python.
It is written by me, and only uses numpy library.
You can try implementing forward propagation of convolutional neural networks with this library and gain a better insight into both forward and backpropagation of convolutional neural networks.
Also you can implement famous architectures like AlexNet, VGG-16, and LeNet-5 to your own models and learn how they work.