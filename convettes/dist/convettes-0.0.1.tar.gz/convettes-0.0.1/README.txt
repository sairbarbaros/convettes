This is a convolutional neural network library for python.
It is written by me, and only uses numpy library.
You can try implementing forward propagation of convolutional neural networks with this library. 
You can also take a look at its functions to gain a better insight into both forward and backpropagation of convolutional neural networks.
